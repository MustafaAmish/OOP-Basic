﻿using System;

namespace DungeonsAndCodeWizards
{
  public  class StartUp
    {
        static void Main()
        {
            var game=new Engine();
            game.Start();
        }
    }
}
