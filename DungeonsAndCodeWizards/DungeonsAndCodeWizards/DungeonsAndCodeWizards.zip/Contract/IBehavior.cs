﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Contract
{
  public  interface IBehavior:IItem
    {

    }
}
