﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Contract
{
  public  interface ICleric:ICharacter,IHealable
    {
    }
}
