﻿using System;
using System.Collections.Generic;
using System.Text;


public enum Season
{
    Autumn=1,
    Spring,
    Winter,
    Summer
}

