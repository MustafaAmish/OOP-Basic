﻿using System;

namespace HotelReservation
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Console.WriteLine( PriceCalculator.CalculatePrice(Console.ReadLine()));
        }
    }
}
