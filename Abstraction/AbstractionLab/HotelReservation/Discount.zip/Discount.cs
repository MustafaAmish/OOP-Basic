﻿using System;
using System.Collections.Generic;
using System.Text;


public enum Discount
{
    SecondVisit=10,
    VIP=20,
    None=0
}

