﻿using System;

namespace HierarchicalInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
