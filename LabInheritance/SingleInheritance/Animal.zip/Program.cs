﻿using System;

namespace SingleInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
