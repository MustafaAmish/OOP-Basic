﻿using System;

namespace StackOfStringss
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
