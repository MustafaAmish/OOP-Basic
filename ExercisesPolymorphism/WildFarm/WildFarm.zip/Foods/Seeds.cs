﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Foods
{
    class Seeds:Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
