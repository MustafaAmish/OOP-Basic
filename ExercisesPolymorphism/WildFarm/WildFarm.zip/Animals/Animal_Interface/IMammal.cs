﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IMammal
{
    string LivingRegion { get; }
}
