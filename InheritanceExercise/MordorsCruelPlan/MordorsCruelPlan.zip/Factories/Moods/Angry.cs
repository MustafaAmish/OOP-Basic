﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Factories.Moods
{
    public class Angry : Mood
    {
        public Angry(int happinessPoints) : base(happinessPoints)
        {
        }
    }
}
