﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IBrowseable
{
    string Browsing(string url);
}