﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBender
{
     string Name { get; }
    int Power { get; }
}