﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Cat:Animal
{
    public Cat(string name, int age, int commmand, string adoptetCenter) : base(name, age, commmand, adoptetCenter)
    {

    }
}