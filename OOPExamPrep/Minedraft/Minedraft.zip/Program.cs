﻿using System;

namespace Minedraft
{
    class Program
    {
        static void Main(string[] args)
        {
           var engin=new Engin();
            engin.Start();
        }
    }
}
