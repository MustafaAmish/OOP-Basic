﻿using System;
using System.Collections.Generic;
using System.Text;

public static class ERRORMESSEG
{
    public static string TyreBlown => $"Blown Tyre";
    public static string Full => $"Out of fuel";
}
