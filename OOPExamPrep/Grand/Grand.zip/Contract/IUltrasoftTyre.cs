﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IUltrasoftTyre:ITyre
{
    double Grip { get; }
}